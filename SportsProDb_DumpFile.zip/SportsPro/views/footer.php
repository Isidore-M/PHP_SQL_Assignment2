</div> <!-- container -->

<footer class="bg-dark text-white text-center py-3 mt-5">
    <small>
        &copy; <?= date('Y') ?> SportsPro Technical Support
    </small>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
